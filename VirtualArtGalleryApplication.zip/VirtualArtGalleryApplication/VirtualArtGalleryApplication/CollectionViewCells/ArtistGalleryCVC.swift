//
//  ArtistGalleryCVC.swift
//  VirtualArtGalleryApplication
//
//  Created by Mounitha Vemula on 03/11/2023.
//

import UIKit

class ArtistGalleryCVC: UICollectionViewCell {
    
    
    @IBOutlet weak var contantView: UIView!
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet var btn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
