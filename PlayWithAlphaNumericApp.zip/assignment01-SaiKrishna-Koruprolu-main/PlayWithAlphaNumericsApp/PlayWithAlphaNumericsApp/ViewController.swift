//
//  ViewController.swift
//  PlayWithAlphaNumericsApp
//
//  Created by Sai Krishna Koruprolu on 13/09/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.headerLBL.text = String(format: "%@\nPlay with AlphaNumerics™️", "\u{0c38}\u{0c4d}\u{0c35}\u{0c3e}\u{0c17}\u{0c24}\u{0c02}")
            
        self.numbersStepper[0].isEnabled=false
        self.numbersStepper[1].isEnabled=false
        
        optionSWCH[0].isOn=false
        optionSWCH[1].isOn=false
        
        stringAndPatternBTN[0].isEnabled=false
        stringAndPatternBTN[1].isEnabled=false
        firstStrTF.isEnabled=false
        secondStrTF.isEnabled=false
        
        }
    
    
    @IBOutlet weak var headerLBL: UILabel!
    
    
    @IBOutlet weak var secondNumLBL: UILabel!
    
    @IBOutlet weak var firstNumLBL: UILabel!
    
    @IBAction func numberSWCH(_ sender: UISwitch) {
        if(sender.isOn==true){
            //enabling
            self.numbersStepper[0].isEnabled=true
            self.numbersStepper[1].isEnabled=true
            self.stringAndPatternBTN[0].isEnabled=true
            self.firstNumLBL.text="0"
            self.secondNumLBL.text="0"
        }else{
            //disabled
            self.firstNumLBL.text="0"
            self.secondNumLBL.text="0"
            numbersStepper[0].value=0
            numbersStepper[1].value=0
        
            self.numbersStepper[0].isEnabled=false
            self.numbersStepper[1].isEnabled=false
            self.stringAndPatternBTN[0].isEnabled=false
            
            messageTV.text=""
        }
    }
    
    @IBAction func stringSWCH(_ sender: UISwitch) {
        if(sender.isOn==true){
            stringAndPatternBTN[1].isEnabled=true
            firstStrTF.isEnabled=true
            secondStrTF.isEnabled=true
        }
else{
    firstStrTF.text=""
    secondStrTF.text=""
            stringAndPatternBTN[1].isEnabled=false
            firstStrTF.isEnabled=false
            secondStrTF.isEnabled=false
        }
    }
    
    @IBOutlet var optionSWCH: [UISwitch]!
    
    @IBOutlet weak var firstStrTF: UITextField!
    
    @IBOutlet weak var secondStrTF: UITextField!
    
    @IBAction func firstNumStepper(_ sender: UIStepper) {
        firstNumLBL.text="\(Int(sender.value))"
    }
    
    @IBAction func secondNumStepper(_ sender: UIStepper) {
        secondNumLBL.text="\(Int(sender.value))"
    }
    
    @IBOutlet var numbersStepper: [UIStepper]!
    
    
    @IBOutlet weak var messageTV: UITextView!
    
    @IBAction func generatePattern(_ sender: UIButton) {
        if firstNumLBL.text == "0" {
            messageTV.text = "First number is invalid. Please provide the number greater than zero."
        }else if secondNumLBL.text=="0"{
            messageTV.text = "Second number is invalid. Please provide the number greater than zero."
                    
        }
        else{
            var opgenerate=""
            if let rows=Int(firstNumLBL.text ?? "0"),
               let columns=Int(secondNumLBL.text ?? "0")
            {
                var count = 0
                for num1 in 1...rows{
                    for num2 in 1...columns{
                        if num1==1 || num1==rows || num2==1 || num2==columns{
                            opgenerate+="❄️"
                        }
                        else{
                            count += 1
                            if count % 2 == 1{
                                opgenerate+="🎅"
                            }else{
                                opgenerate+="🌲"
                            }
                        }
                    }
                    
                    opgenerate+="\n"
                }
            }
            messageTV.text=opgenerate
        }
        }
    

    @IBAction func manipulateStrings(_ sender: UIButton) {
        if firstStrTF.text==""{
            messageTV.text="Given First String value is invalid. Please enter atleast one character."
        }
        else if secondStrTF.text==""{
            messageTV.text="Given Second String value is invalid. Please enter atleast one character."
        }
        else{
            messageTV.text=""
            let stringg1:String
            stringg1=firstStrTF.text!
            let stringg2:String
            stringg2=secondStrTF.text!
            let concatenate = stringg1 + stringg2
            messageTV.text="""
 concatenation of two strings result in "\(concatenate)".\n
"""
            
            let str=concatenate.lowercased()
            var x1=0,x2=0
            let vowel="aeiou"
            let conson="bcdfghjklmnpqrstvwxyz"
            for i in str{
                if vowel.contains(i)
                {
                    x1+=1
                }
                else if conson.contains(i)
                {
                    x2+=1
                }
            }
            messageTV.text+="""
Number of vowels in "\(concatenate)" is \(x1).\n
"""
            messageTV.text+="""
Number of consonants in "\(concatenate)" is \(x2).\n
"""
            
            var texxt=""
            
            for i in str{
                if(!texxt.contains(i)){
                    texxt.append(i)
                }
            }
            
            messageTV.text+="""
Number of unique characters in "\(concatenate)" is \(texxt.count).\n
"""
            let reverse=String(concatenate.reversed())
            messageTV.text+="""
The reversal of "\(concatenate)" results in "\(reverse)".
"""
        }
    }
        
    @IBOutlet var stringAndPatternBTN: [UIButton]!
    
    
    @IBAction func onReset(_ sender: UIButton) {
        optionSWCH[0].isOn=false
        optionSWCH[1].isOn=false
        messageTV.text=""
        
        stringAndPatternBTN[0].isEnabled=false
        stringAndPatternBTN[1].isEnabled=false
        
        numbersStepper[0].isEnabled=false
        numbersStepper[0].value=0
        numbersStepper[1].value=0
        numbersStepper[1].isEnabled=false
        firstStrTF.text=""
        secondStrTF.text=""
        firstNumLBL.text="0"
        secondNumLBL.text="0"
        
    }
}
